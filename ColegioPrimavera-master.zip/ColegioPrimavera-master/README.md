Integrantes:
Erick Jara, Matias Caqueo, Jose Vejar, Pablo Pardo
